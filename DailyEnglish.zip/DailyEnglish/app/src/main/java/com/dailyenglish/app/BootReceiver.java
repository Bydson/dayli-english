package com.dailyenglish.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the phrase service after the phone reboots or the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent intent) {
        if (new Prefs(ctx).enabled()) {
            try {
                PhraseService.start(ctx);
            } catch (RuntimeException ignored) {
                // Some systems block background starts; opening the app starts it again.
            }
        }
    }
}
