package com.dailyenglish.app;

/**
 * Phrase bank (B1-B2, everyday spoken English) and the logic that picks
 * today's set. Each entry: { English, Russian, example }.
 * 200 phrases / 5 per day = a new set every day for 40 days, then it repeats.
 */
public final class Phrases {

    public static final int PER_DAY = 5;

    public static final String[][] ALL = {
        // 1
        {"It's up to you", "Решай сам / Как скажешь", "Pizza or sushi? It's up to you."},
        {"I'm running late", "Я опаздываю", "Sorry, I'm running late. I'll be there in ten minutes."},
        {"figure out", "разобраться, понять", "I can't figure out how this works."},
        {"No wonder", "Неудивительно", "No wonder you're tired — you worked a night shift."},
        {"make sense", "иметь смысл, быть понятным", "Does that make sense to you?"},
        // 2
        {"I'm not really into it", "Мне это не особо нравится", "Horror films? I'm not really into them."},
        {"get used to", "привыкнуть к", "I'm still getting used to the new schedule."},
        {"How come?", "Как так? Почему?", "How come you're still awake?"},
        {"Take your time", "Не торопись", "No rush, take your time."},
        {"I can't stand it", "Терпеть не могу", "I can't stand waiting in queues."},
        // 3
        {"look forward to", "с нетерпением ждать", "I'm looking forward to the weekend."},
        {"It depends", "Смотря как / Зависит от обстоятельств", "Are we going out? It depends on the weather."},
        {"run out of", "закончиться (о запасах)", "We've run out of milk."},
        {"By the way", "Кстати", "By the way, did you call your mum?"},
        {"I'm in the middle of something", "Я сейчас кое-чем занят", "Can I call you back? I'm in the middle of something."},
        // 4
        {"turn out", "оказаться", "It turned out to be easier than I thought."},
        {"That's a good point", "Справедливое замечание", "That's a good point, I didn't think of that."},
        {"give up", "сдаться, бросить", "Don't give up — you're almost there."},
        {"I'd rather…", "Я бы лучше… / Я бы предпочёл…", "I'd rather stay home tonight."},
        {"Never mind", "Неважно, забудь", "Never mind, I found it."},
        // 5
        {"catch up", "наверстать; пообщаться после перерыва", "Let's meet for coffee and catch up."},
        {"It's not a big deal", "Ничего страшного", "Don't worry, it's not a big deal."},
        {"come up with", "придумать", "She came up with a great idea."},
        {"Fair enough", "Справедливо, логично", "You're tired? Fair enough, let's go tomorrow."},
        {"I'm starving", "Умираю с голоду", "Let's eat, I'm starving."},
        // 6
        {"work out", "тренироваться; получиться", "I hope everything works out for you."},
        {"Sounds good", "Звучит неплохо / Договорились", "Dinner at seven? Sounds good."},
        {"keep in touch", "оставаться на связи", "It was great to see you. Let's keep in touch!"},
        {"I didn't catch that", "Я не расслышал", "Sorry, I didn't catch that. Could you say it again?"},
        {"end up", "в итоге оказаться / сделать", "We ended up staying until midnight."},
        // 7
        {"I'm on my way", "Я уже в пути", "I'm on my way, see you soon."},
        {"put off", "откладывать", "Stop putting off your English practice!"},
        {"Just in case", "На всякий случай", "Take an umbrella, just in case."},
        {"What's the point?", "Какой смысл?", "What's the point of waiting? Let's go."},
        {"I'm exhausted", "Я вымотан", "After a night shift I'm completely exhausted."},
        // 8
        {"deal with", "справляться с, разбираться с", "I'll deal with it tomorrow."},
        {"So far so good", "Пока всё хорошо", "How's the new job? — So far so good."},
        {"I'm fed up with…", "Мне надоело…", "I'm fed up with this rain."},
        {"pick up", "забрать; подхватить (навык)", "I'll pick you up at eight."},
        {"Let me know", "Дай мне знать", "Let me know if you need any help."},
        // 9
        {"show up", "появиться, прийти", "He didn't show up to the meeting."},
        {"It's worth it", "Оно того стоит", "The trip is long, but it's worth it."},
        {"I couldn't care less", "Мне совершенно всё равно", "Celebrity gossip? I couldn't care less."},
        {"find out", "узнать, выяснить", "I need to find out when the shop opens."},
        {"out of the blue", "ни с того ни с сего, внезапно", "He called me out of the blue."},
        // 10
        {"set up", "настроить, организовать", "Can you help me set up my new phone?"},
        {"Hang on a second", "Подожди секунду", "Hang on a second, I'll get my keys."},
        {"I'm into…", "Я увлекаюсь…", "I'm really into cooking these days."},
        {"get along with", "ладить с", "I get along well with my colleagues."},
        {"It slipped my mind", "Совсем вылетело из головы", "Sorry, it completely slipped my mind."},
        // 11
        {"look up", "поискать (информацию)", "If you don't know the word, look it up."},
        {"Better late than never", "Лучше поздно, чем никогда", "You finally started learning English? Better late than never!"},
        {"I'm up for it", "Я за! Я в деле", "A swim tomorrow? I'm up for it."},
        {"go through", "пережить; просмотреть", "She's going through a hard time."},
        {"Take it easy", "Не напрягайся, отдохни", "Take it easy, you've had a long day."},
        // 12
        {"make up your mind", "решиться, определиться", "Make up your mind — tea or coffee?"},
        {"I'm on it", "Уже занимаюсь этим", "Can you fix this? — I'm on it."},
        {"get rid of", "избавиться от", "I need to get rid of these old clothes."},
        {"Long time no see", "Сто лет не виделись", "Hey, long time no see! How are you?"},
        {"Speaking of which", "Кстати об этом", "Speaking of which, have you eaten yet?"},
        // 13
        {"come across", "наткнуться, случайно найти", "I came across an interesting article."},
        {"I haven't got a clue", "Понятия не имею", "Where are my keys? I haven't got a clue."},
        {"It's a piece of cake", "Проще простого", "Don't worry, the test is a piece of cake."},
        {"carry on", "продолжать", "Sorry for interrupting, carry on."},
        {"I'm all ears", "Я весь внимание", "Tell me what happened, I'm all ears."},
        // 14
        {"check out", "посмотреть, заценить", "Check out this video, it's hilarious!"},
        {"Let's call it a day", "На сегодня хватит", "We've done enough. Let's call it a day."},
        {"count on", "рассчитывать на", "You can always count on me."},
        {"I'm glad to hear that", "Рад это слышать", "You feel better? I'm glad to hear that."},
        {"break down", "сломаться", "My car broke down on the way to work."},
        // 15
        {"Mind your own business", "Не лезь не в своё дело", "Who was that on the phone? — Mind your own business!"},
        {"go on", "продолжать; происходить", "What's going on here?"},
        {"As far as I know", "Насколько я знаю", "As far as I know, the shop is closed on Sundays."},
        {"hang out", "проводить время, тусоваться", "We hung out at the park all afternoon."},
        {"I'm feeling under the weather", "Мне нездоровится", "I'm staying home, I'm feeling a bit under the weather."},
        // 16
        {"take off", "снять (одежду); взлететь", "Please take off your shoes."},
        {"Don't get me wrong", "Не пойми меня неправильно", "Don't get me wrong, I like him, but he talks too much."},
        {"fill out", "заполнить (анкету)", "Please fill out this form."},
        {"That's the last thing I need", "Только этого мне не хватало", "Rain? That's the last thing I need today."},
        {"call off", "отменить", "They called off the match because of the rain."},
        // 17
        {"in the long run", "в долгосрочной перспективе", "Practising every day helps in the long run."},
        {"pay off", "окупиться, принести результат", "All that hard work finally paid off."},
        {"I see what you mean", "Понимаю, о чём ты", "I see what you mean, but I don't agree."},
        {"run into", "случайно встретить", "I ran into an old friend at the supermarket."},
        {"Keep it up!", "Так держать!", "Your English is getting better. Keep it up!"},
        // 18
        {"look after", "присматривать, заботиться", "Could you look after my cat this weekend?"},
        {"Let's get started", "Давай начнём", "Everyone's here, so let's get started."},
        {"cut down on", "сократить (потребление)", "I'm trying to cut down on sugar."},
        {"Whatever you say", "Как скажешь", "We're leaving at five? Whatever you say."},
        {"bring up", "поднять (тему)", "Please don't bring up politics at dinner."},
        // 19
        {"It's on me", "Я угощаю", "Put your wallet away, it's on me."},
        {"get over", "пережить, оправиться", "It took me two weeks to get over the flu."},
        {"Not that I know of", "Насколько мне известно, нет", "Is he coming? — Not that I know of."},
        {"point out", "указать, обратить внимание", "Thanks for pointing out my mistake."},
        {"I'm short on time", "У меня мало времени", "Can we talk later? I'm short on time."},
        // 20
        {"drop by", "заскочить, зайти ненадолго", "Drop by whenever you like."},
        {"Way to go!", "Молодец! Отлично!", "You passed the exam? Way to go!"},
        {"work on", "работать над", "I'm working on my pronunciation."},
        {"That rings a bell", "Что-то знакомое", "Her name rings a bell, but I can't remember her face."},
        {"sort out", "уладить, разобраться", "Don't worry, we'll sort it out."},
        // 21
        {"I'm not in the mood", "Нет настроения", "I'm not in the mood for a party tonight."},
        {"get back to", "ответить позже; вернуться к", "I'll get back to you tomorrow."},
        {"once in a while", "время от времени", "I eat fast food once in a while."},
        {"throw away", "выбросить", "Don't throw away the box, we might need it."},
        {"Fingers crossed!", "Скрестим пальцы! / Надеюсь, повезёт", "I have an interview tomorrow. Fingers crossed!"},
        // 22
        {"oversleep", "проспать", "I overslept and missed the bus."},
        {"That's what I thought", "Так я и думал", "It's closed? That's what I thought."},
        {"back up", "поддержать; сделать резервную копию", "Always back up your files."},
        {"I can't help it", "Ничего не могу с собой поделать", "I can't help laughing when I see him."},
        {"sign up for", "записаться на", "I signed up for a swimming course."},
        // 23
        {"Easier said than done", "Легче сказать, чем сделать", "Just relax? Easier said than done."},
        {"warm up", "разогреть; размяться", "Always warm up before you swim."},
        {"Same here", "У меня тоже / Я тоже", "I'm so tired. — Same here."},
        {"slow down", "притормозить, не спешить", "Slow down, I can't understand you."},
        {"To be honest", "Честно говоря", "To be honest, I didn't like the film."},
        // 24
        {"keep up with", "поспевать за", "It's hard to keep up with all the news."},
        {"Better safe than sorry", "Лучше перестраховаться", "I'll check the door again — better safe than sorry."},
        {"stay up", "не ложиться спать", "We stayed up all night talking."},
        {"I owe you one", "Я твой должник", "Thanks for the help, I owe you one."},
        {"calm down", "успокоиться", "Calm down, everything will be fine."},
        // 25
        {"It's not the end of the world", "Это не конец света", "You missed the bus? It's not the end of the world."},
        {"get on my nerves", "действовать на нервы", "That noise is getting on my nerves."},
        {"rely on", "полагаться на", "You can't always rely on the weather forecast."},
        {"in a nutshell", "в двух словах, короче", "In a nutshell, the plan didn't work."},
        {"Go for it!", "Действуй! Рискни!", "You want to learn the guitar? Go for it!"},
        // 26
        {"do the dishes", "мыть посуду", "I cooked, so you do the dishes."},
        {"I'll take your word for it", "Поверю тебе на слово", "The soup is great? I'll take your word for it."},
        {"fall asleep", "заснуть", "I fell asleep on the sofa again."},
        {"out of order", "не работает (о технике)", "The lift is out of order."},
        {"chill out", "расслабиться", "Let's just chill out at home tonight."},
        // 27
        {"off the top of my head", "навскидку, сходу", "Off the top of my head, I'd say about fifty people."},
        {"turn down", "отклонить; убавить (звук)", "She turned down the job offer."},
        {"It's about time", "Давно пора", "It's about time you got a haircut."},
        {"hold on", "подождать; держаться", "Hold on, I'm almost ready."},
        {"I'm broke", "Я на мели (нет денег)", "I can't go out this week, I'm broke."},
        // 28
        {"get ready", "собираться, готовиться", "Get ready, we're leaving in five minutes."},
        {"I couldn't agree more", "Полностью согласен", "Sleep is important. — I couldn't agree more."},
        {"make it", "успеть; смочь прийти", "Sorry, I can't make it tonight."},
        {"That's the spirit!", "Вот это настрой!", "I'll try again tomorrow. — That's the spirit!"},
        {"come over", "зайти в гости", "Come over tonight, I'm cooking pasta."},
        // 29
        {"for good", "навсегда", "He moved to Spain for good."},
        {"take care of", "позаботиться о; заняться", "I'll take care of the tickets."},
        {"What a relief!", "Какое облегчение!", "You found your phone? What a relief!"},
        {"mix up", "перепутать", "I always mix up these two words."},
        {"It's none of my business", "Это не моё дело", "It's none of my business, but I think you should call her."},
        // 30
        {"wear out", "вымотать; износиться", "This job really wears me out."},
        {"On second thought", "Хотя, если подумать…", "On second thought, let's stay in."},
        {"put up with", "терпеть, мириться с", "I can't put up with this noise anymore."},
        {"Good for you!", "Молодец! Рад за тебя!", "You went to the pool twice this week? Good for you!"},
        {"Go ahead", "Давай, конечно (разрешаю)", "Can I use your charger? — Sure, go ahead."},
        // 31
        {"I'm about to…", "Я как раз собираюсь…", "I'm about to leave. Can I call you later?"},
        {"think it over", "обдумать", "Let me think it over and I'll tell you tomorrow."},
        {"Don't mention it", "Не за что", "Thanks a lot! — Don't mention it."},
        {"head out", "выходить, отправляться", "I'm heading out. Do you need anything from the shop?"},
        {"a bit of a…", "немного, своего рода", "It's a bit of a problem, to be honest."},
        // 32
        {"get the hang of it", "освоиться, набить руку", "Don't worry, you'll get the hang of it soon."},
        {"I'm all set", "У меня всё готово", "Do you need anything else? — No thanks, I'm all set."},
        {"run errands", "бегать по делам", "I spent the morning running errands."},
        {"Nothing special", "Ничего особенного", "What did you do yesterday? — Nothing special."},
        {"take up", "начать заниматься (хобби)", "I took up swimming last year."},
        // 33
        {"I'll keep that in mind", "Учту, буду иметь в виду", "Thanks for the advice, I'll keep that in mind."},
        {"look into", "изучить, разобраться", "I'll look into the problem tomorrow."},
        {"Let's split the bill", "Давай разделим счёт", "That was a great dinner. Let's split the bill."},
        {"fall apart", "развалиться", "My old shoes are falling apart."},
        {"Tell me about it!", "И не говори! (полностью согласен)", "Mondays are terrible. — Tell me about it!"},
        // 34
        {"give it a shot", "попробовать", "I've never tried sushi, but I'll give it a shot."},
        {"It's getting late", "Уже поздно", "It's getting late, I should go home."},
        {"hand in", "сдать (работу, документы)", "Please hand in your report by Friday."},
        {"kind of", "вроде как, немного", "I'm kind of busy right now."},
        {"It doesn't matter", "Это не важно", "It doesn't matter what you wear."},
        // 35
        {"back out", "отказаться (от обещания)", "He backed out at the last minute."},
        {"the other way around", "наоборот", "It's not my fault — it's the other way around."},
        {"I'm off", "Я пошёл / Я ухожу", "Right, I'm off. See you tomorrow!"},
        {"on the go", "на ходу, в постоянном движении", "I've been on the go all day."},
        {"blow it", "упустить шанс, провалить", "I had one chance and I blew it."},
        // 36
        {"Let's play it by ear", "Сориентируемся по ситуации", "I don't know when I'll finish. Let's play it by ear."},
        {"mess up", "напортачить, испортить", "I messed up the recipe."},
        {"No hard feelings", "Без обид", "You won fair and square. No hard feelings."},
        {"move on", "двигаться дальше", "It's time to forget it and move on."},
        {"It's not my cup of tea", "Это не моё", "Opera is not really my cup of tea."},
        // 37
        {"Keep me posted", "Держи меня в курсе", "Keep me posted about the new job."},
        {"get the point", "понять суть", "I get the point, you don't need to repeat it."},
        {"make a living", "зарабатывать на жизнь", "What does she do for a living?"},
        {"I didn't mean to", "Я не хотел (это случайно)", "Sorry, I didn't mean to wake you up."},
        {"brush up on", "освежить (знания)", "I need to brush up on my English."},
        // 38
        {"cheer up", "приободриться", "Cheer up! It's almost Friday."},
        {"Not bad at all", "Совсем неплохо", "How was the film? — Not bad at all."},
        {"dress up", "нарядиться", "Do I need to dress up for the party?"},
        {"Make yourself at home", "Чувствуй себя как дома", "Come in and make yourself at home."},
        {"pass out", "отключиться (от усталости); потерять сознание", "I passed out as soon as I got home."},
        // 39
        {"I'm done", "Я закончил / С меня хватит", "I'm done for today, let's go home."},
        {"give me a hand", "помоги мне", "Can you give me a hand with these bags?"},
        {"save up for", "копить на", "I'm saving up for a new laptop."},
        {"What's the catch?", "В чём подвох?", "A free phone? What's the catch?"},
        {"be in charge of", "отвечать за", "Who's in charge of the project?"},
        // 40
        {"Let it go", "Отпусти, забудь", "It was a long time ago. Just let it go."},
        {"on purpose", "нарочно", "I didn't do it on purpose!"},
        {"Here we go again", "Ну вот, опять", "Another traffic jam? Here we go again."},
        {"by heart", "наизусть", "I know his phone number by heart."},
        {"step by step", "шаг за шагом", "Learn new words step by step."},
    };

    private Phrases() {}

    public static int setCount() {
        return ALL.length / PER_DAY;
    }

    /** Index of the phrase set for the given "phrase day" (see Prefs.phraseDay). */
    public static int setIndexFor(long day, long startDay) {
        long n = setCount();
        long idx = (day - startDay) % n;
        if (idx < 0) idx += n;
        return (int) idx;
    }

    /** The phrases for one set, in order. */
    public static String[][] set(int setIndex) {
        String[][] out = new String[PER_DAY][];
        for (int i = 0; i < PER_DAY; i++) {
            out[i] = ALL[setIndex * PER_DAY + i];
        }
        return out;
    }
}
