package com.dailyenglish.app;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Runs in the background while enabled. When the phone is unlocked or in use,
 * it shows a small card with one of today's phrases over whatever app is open,
 * no more often than the chosen interval.
 */
public class PhraseService extends Service {

    public static final String ACTION_SHOW_NOW = "com.dailyenglish.app.SHOW_NOW";
    public static final String ACTION_REFRESH = "com.dailyenglish.app.REFRESH";

    private static final String CHANNEL_ID = "daily_phrases";
    private static final int NOTIF_ID = 1;
    private static final long TICK_MS = 60_000;          // check once a minute while in use
    private static final long AUTO_HIDE_MS = 15_000;     // card disappears after 15 s
    private static final long UNLOCK_DELAY_MS = 1_500;   // let the home screen settle first

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Prefs prefs;
    private WindowManager wm;
    private View overlay;
    private long notifDay = -1;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            maybeShow(false);
            handler.postDelayed(this, TICK_MS);
        }
    };

    private final Runnable hide = this::removeOverlay;

    private final Runnable stopIfDisabled = () -> {
        if (!prefs.enabled()) stopSelf();
    };

    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_USER_PRESENT.equals(a)) {
                handler.removeCallbacks(tick);
                handler.postDelayed(tick, UNLOCK_DELAY_MS);
            } else if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                handler.removeCallbacks(tick);
                removeOverlay();
            } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                // Phones without a lock screen never send USER_PRESENT.
                handler.removeCallbacks(tick);
                handler.postDelayed(tick, UNLOCK_DELAY_MS);
            }
        }
    };

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, PhraseService.class);
        ctx.startForegroundService(i);
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, PhraseService.class));
    }

    @Override public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        startInForeground();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_USER_PRESENT);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenReceiver, f);

        handler.post(tick);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startInForeground();
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_SHOW_NOW.equals(action)) {
            handler.post(() -> maybeShow(true));
        }
        handler.removeCallbacks(stopIfDisabled);
        if (!prefs.enabled()) {
            // Started only for the "show now" test: shut down again afterwards.
            handler.postDelayed(stopIfDisabled, 2 * 60_000);
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try { unregisterReceiver(screenReceiver); } catch (IllegalArgumentException ignored) {}
        removeOverlay();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    // ---------- showing the card ----------

    private void maybeShow(boolean force) {
        refreshNotificationIfNewDay();
        if (!Settings.canDrawOverlays(this)) return;
        if (!force) {
            if (!prefs.enabled()) return;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (pm == null || !pm.isInteractive()) return;
            if (km != null && km.isKeyguardLocked()) return;
            long since = System.currentTimeMillis() - prefs.lastShownMs();
            if (since < prefs.intervalMin() * 60_000L) return;
        }
        showPhrase(prefs.nextPhrase());
    }

    private void showPhrase(String[] p) {
        removeOverlay();
        prefs.setLastShownMs(System.currentTimeMillis());

        FrameLayout root = new FrameLayout(this);
        int m = dp(12);
        root.setPadding(m, dp(8), m, 0);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1F4E79"));
        bg.setCornerRadius(dp(20));
        card.setBackground(bg);
        card.setElevation(dp(8));

        // Header: label + close
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text("DAILY ENGLISH", 12, "#F2B134", true);
        label.setLetterSpacing(0.12f);
        header.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = text("✕", 18, "#BFD3E6", false);
        close.setPadding(dp(12), 0, 0, 0);
        close.setOnClickListener(v -> removeOverlay());
        header.addView(close);
        card.addView(header);

        TextView en = text(p[0], 22, "#FFFFFF", true);
        en.setPadding(0, dp(6), 0, 0);
        card.addView(en);

        TextView ru = text(p[1], 16, "#D6E4F0", false);
        ru.setPadding(0, dp(2), 0, 0);
        card.addView(ru);

        TextView ex = text(p[2], 14, "#AFC6DB", false);
        ex.setTypeface(Typeface.DEFAULT, Typeface.ITALIC);
        ex.setPadding(0, dp(8), 0, 0);
        card.addView(ex);

        TextView next = text("Ещё фраза →", 14, "#F2B134", true);
        next.setPadding(0, dp(10), 0, 0);
        next.setOnClickListener(v -> showPhrase(prefs.nextPhrase()));
        card.addView(next);

        card.setOnClickListener(v -> removeOverlay());
        root.addView(card, new FrameLayout.LayoutParams(-1, -2));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        lp.y = statusBarHeight();
        lp.windowAnimations = android.R.style.Animation_Toast;

        try {
            wm.addView(root, lp);
            overlay = root;
            handler.removeCallbacks(hide);
            handler.postDelayed(hide, AUTO_HIDE_MS);
        } catch (RuntimeException e) {
            overlay = null; // permission revoked or window refused
        }
    }

    private void removeOverlay() {
        handler.removeCallbacks(hide);
        if (overlay != null) {
            try { wm.removeView(overlay); } catch (RuntimeException ignored) {}
            overlay = null;
        }
    }

    private TextView text(String s, int sp, String color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.parseColor(color));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    // ---------- notification ----------

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Фразы дня", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Показывает фразы на сегодня");
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        String[][] today = prefs.todaysPhrases();
        StringBuilder sb = new StringBuilder();
        for (String[] p : today) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(p[0]).append(" — ").append(p[1]);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("Фразы на сегодня")
                .setContentText(today[0][0] + " · " + today[1][0] + " · …")
                .setStyle(new Notification.BigTextStyle().bigText(sb.toString()))
                .setContentIntent(open)
                .setOngoing(true)
                .setShowWhen(false)
                .build();
    }

    private void startInForeground() {
        notifDay = prefs.phraseDay();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void refreshNotificationIfNewDay() {
        long day = prefs.phraseDay();
        if (day != notifDay) {
            notifDay = day;
            getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification());
        }
    }
}
