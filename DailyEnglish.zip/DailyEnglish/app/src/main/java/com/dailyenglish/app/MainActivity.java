package com.dailyenglish.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Settings screen + list of today's phrases. Built in code, no XML layouts. */
public class MainActivity extends Activity {

    private static final String BG = "#F4F6F9";
    private static final String INK = "#1B2430";
    private static final String MUTED = "#5F6B7A";
    private static final String BRAND = "#1F4E79";
    private static final String ACCENT = "#F2B134";

    private Prefs prefs;
    private LinearLayout content;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        getWindow().setStatusBarColor(Color.parseColor(BRAND));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor(BG));
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(20), dp(16), dp(32));
        scroll.addView(content);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Rebuild every time: the user may come back from a permission screen.
        if (prefs.enabled() && Settings.canDrawOverlays(this)) PhraseService.start(this);
        render();
    }

    private void render() {
        content.removeAllViews();

        TextView title = text("Daily English", 28, INK, true);
        content.addView(title);
        TextView sub = text("Фразы дня · набор " + prefs.todaysSetNumber() + " из " + Phrases.setCount()
                + "\nНовые фразы каждое утро в " + prefs.changeHour() + ":00", 14, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(16));
        content.addView(sub);

        // ---- permissions ----
        boolean overlayOk = Settings.canDrawOverlays(this);
        if (!overlayOk) {
            LinearLayout warn = card("#FFF4DB");
            warn.addView(text("Нужно разрешение", 16, INK, true));
            TextView t = text("Чтобы фразы появлялись поверх других приложений, включи для Daily English "
                    + "«Показ поверх других приложений».", 14, MUTED, false);
            t.setPadding(0, dp(4), 0, dp(10));
            warn.addView(t);
            warn.addView(button("Открыть настройки", true, v -> startActivity(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())))));
            content.addView(warn);
        }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            LinearLayout bat = card("#FFFFFF");
            bat.addView(text("Работа в фоне", 16, INK, true));
            TextView t = text("Разреши работу без ограничений батареи, иначе телефон может "
                    + "выключать приложение и фразы перестанут появляться.", 14, MUTED, false);
            t.setPadding(0, dp(4), 0, dp(10));
            bat.addView(t);
            bat.addView(button("Разрешить", false, v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (RuntimeException e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            }));
            content.addView(bat);
        }

        // ---- main switch + settings ----
        LinearLayout settings = card("#FFFFFF");
        Switch sw = new Switch(this);
        sw.setText("Показывать фразы");
        sw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        sw.setTextColor(Color.parseColor(INK));
        sw.setTypeface(Typeface.DEFAULT_BOLD);
        sw.setChecked(prefs.enabled());
        sw.setOnCheckedChangeListener((btn, on) -> {
            if (on && !Settings.canDrawOverlays(this)) {
                btn.setChecked(false);
                Toast.makeText(this, "Сначала дай разрешение выше", Toast.LENGTH_LONG).show();
                return;
            }
            prefs.setEnabled(on);
            if (on) PhraseService.start(this); else PhraseService.stop(this);
        });
        settings.addView(sw);

        settings.addView(label("Как часто показывать"));
        settings.addView(chips(intervalLabels(), indexOf(Prefs.INTERVALS, prefs.intervalMin()), i -> {
            prefs.setIntervalMin(Prefs.INTERVALS[i]);
            render();
        }));

        settings.addView(label("Во сколько менять фразы утром"));
        String[] hours = new String[Prefs.CHANGE_HOURS.length];
        for (int i = 0; i < hours.length; i++) hours[i] = Prefs.CHANGE_HOURS[i] + ":00";
        settings.addView(chips(hours, indexOf(Prefs.CHANGE_HOURS, prefs.changeHour()), i -> {
            prefs.setChangeHour(Prefs.CHANGE_HOURS[i]);
            if (prefs.enabled()) {
                startForegroundService(new Intent(this, PhraseService.class)
                        .setAction(PhraseService.ACTION_REFRESH));
            }
            render();
        }));

        View gap = new View(this);
        settings.addView(gap, new LinearLayout.LayoutParams(1, dp(14)));
        settings.addView(button("Показать фразу сейчас", false, v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала дай разрешение выше", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, PhraseService.class).setAction(PhraseService.ACTION_SHOW_NOW);
            startForegroundService(i);
            if (!prefs.enabled()) {
                Toast.makeText(this, "Включи «Показывать фразы», чтобы они появлялись сами",
                        Toast.LENGTH_LONG).show();
            }
        }));
        content.addView(settings);

        // ---- today's phrases ----
        TextView h = text("Сегодня учим", 20, INK, true);
        h.setPadding(dp(4), dp(18), 0, dp(8));
        content.addView(h);
        for (String[] p : prefs.todaysPhrases()) {
            LinearLayout c = card("#FFFFFF");
            c.addView(text(p[0], 19, BRAND, true));
            TextView ru = text(p[1], 15, INK, false);
            ru.setPadding(0, dp(2), 0, 0);
            c.addView(ru);
            TextView ex = text(p[2], 14, MUTED, false);
            ex.setTypeface(Typeface.DEFAULT, Typeface.ITALIC);
            ex.setPadding(0, dp(6), 0, 0);
            c.addView(ex);
            content.addView(c);
        }
    }

    // ---------- small UI helpers ----------

    interface OnPick { void pick(int i); }

    private String[] intervalLabels() {
        String[] s = new String[Prefs.INTERVALS.length];
        for (int i = 0; i < s.length; i++) {
            int m = Prefs.INTERVALS[i];
            s[i] = m < 60 ? m + " мин" : (m / 60) + " ч";
        }
        return s;
    }

    private static int indexOf(int[] arr, int v) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return 0;
    }

    private LinearLayout chips(String[] labels, int selected, OnPick onPick) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == selected;
            TextView c = text(labels[i], 14, on ? "#FFFFFF" : INK, on);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(4), dp(9), dp(4), dp(9));
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            if (on) {
                bg.setColor(Color.parseColor(BRAND));
            } else {
                bg.setColor(Color.parseColor("#EEF2F6"));
            }
            c.setBackground(bg);
            c.setOnClickListener(v -> onPick.pick(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.leftMargin = dp(6);
            row.addView(c, lp);
        }
        return row;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, MUTED, false);
        t.setPadding(0, dp(16), 0, dp(8));
        return t;
    }

    private Button button(String s, boolean primary, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(s);
        btn.setAllCaps(false);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.parseColor(primary ? INK : BRAND));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        if (primary) {
            bg.setColor(Color.parseColor(ACCENT));
        } else {
            bg.setColor(Color.parseColor("#E3ECF5"));
        }
        btn.setBackground(bg);
        btn.setStateListAnimator(null);
        btn.setOnClickListener(l);
        return btn;
    }

    private LinearLayout card(String color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(color));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.parseColor("#E1E6EC"));
        c.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView text(String s, int sp, String color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.parseColor(color));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
