package com.dailyenglish.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDateTime;

/** Small wrapper around SharedPreferences for all app settings and state. */
public final class Prefs {

    private static final String FILE = "daily_english";

    public static final int[] INTERVALS = {15, 30, 60, 120};
    public static final int[] CHANGE_HOURS = {4, 5, 6, 7, 8};

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
        if (!sp.contains("start_day")) {
            // The first day the app is used gets phrase set #1.
            sp.edit().putLong("start_day", phraseDay()).apply();
        }
    }

    public boolean enabled() { return sp.getBoolean("enabled", false); }
    public void setEnabled(boolean v) { sp.edit().putBoolean("enabled", v).apply(); }

    /** Minimum minutes between two pop-ups. */
    public int intervalMin() { return sp.getInt("interval_min", 30); }
    public void setIntervalMin(int v) { sp.edit().putInt("interval_min", v).apply(); }

    /** Hour of the morning when the new phrases of the day appear. */
    public int changeHour() { return sp.getInt("change_hour", 5); }
    public void setChangeHour(int v) { sp.edit().putInt("change_hour", v).apply(); }

    public long lastShownMs() { return sp.getLong("last_shown_ms", 0); }
    public void setLastShownMs(long v) { sp.edit().putLong("last_shown_ms", v).apply(); }

    /**
     * The "phrase day": the calendar date, but it only switches at changeHour
     * in the morning, so a night shift at 02:00 still shows yesterday's set.
     */
    public long phraseDay() {
        int h = sp.getInt("change_hour", 5);
        return LocalDateTime.now().minusHours(h).toLocalDate().toEpochDay();
    }

    public String[][] todaysPhrases() {
        int idx = Phrases.setIndexFor(phraseDay(), sp.getLong("start_day", phraseDay()));
        return Phrases.set(idx);
    }

    public int todaysSetNumber() {
        return Phrases.setIndexFor(phraseDay(), sp.getLong("start_day", phraseDay())) + 1;
    }

    /** Returns the next phrase of today's set, cycling through all of them. */
    public String[] nextPhrase() {
        long day = phraseDay();
        int pos = 0;
        if (sp.getLong("cursor_day", -1) == day) {
            pos = sp.getInt("cursor_pos", 0);
        }
        String[][] today = todaysPhrases();
        String[] p = today[pos % today.length];
        sp.edit().putLong("cursor_day", day).putInt("cursor_pos", (pos + 1) % today.length).apply();
        return p;
    }
}
